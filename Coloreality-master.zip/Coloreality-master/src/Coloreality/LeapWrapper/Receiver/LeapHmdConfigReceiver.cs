﻿namespace Coloreality.LeapWrapper.Receiver
{
    public class LeapHmdConfigReceiver : SimulatorBase<LeapHmdConfig>
    {
        public LeapHmdConfigReceiver() : base(LeapHmdConfig.DataIndex) { }
    }
}
