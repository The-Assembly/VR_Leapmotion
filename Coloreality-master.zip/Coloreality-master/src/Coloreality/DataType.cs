﻿namespace Coloreality
{
    public enum DataType
    {
        Unknown = -1,
        Byte = 0,
        String,
        Close,
        PreSerialization,
        Serialization,
    }

}